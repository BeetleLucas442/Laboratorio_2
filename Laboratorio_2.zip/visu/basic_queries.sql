USE streamers_db;

-- B1. WHERE with two conditions:
-- Which streamers have more than 5 million followers and stream at least 6 days per week?
SELECT name, total_followers, active_days_per_week
FROM streamer
WHERE total_followers > 5000000
  AND active_days_per_week >= 6
ORDER BY total_followers DESC;

-- B2. JOIN of two entities:
-- Who are the 10 streamers with the most followers and what language do they stream in?
SELECT s.name AS streamer, l.name AS language, s.total_followers
FROM streamer s
JOIN language l ON l.language_id = s.language_id
ORDER BY s.total_followers DESC
LIMIT 10;

-- B3. JOIN of three or more entities:
-- What main game and language do the 10 streamers with the most average viewers per stream have?
SELECT s.name AS streamer, l.name AS language, g.name AS main_game,
       s.avg_viewers_per_stream
FROM streamer s
JOIN language l ON l.language_id = s.language_id
JOIN streamer_game sg ON sg.streamer_id = s.streamer_id AND sg.position = 1
JOIN game g ON g.game_id = sg.game_id
ORDER BY s.avg_viewers_per_stream DESC
LIMIT 10;

-- B4. Aggregation with GROUP BY:
-- How many total views does each language accumulate (only languages with at least 10 streamers)?
SELECT l.name AS language, COUNT(*) AS streamers, SUM(s.total_views) AS total_views
FROM streamer s
JOIN language l ON l.language_id = s.language_id
GROUP BY l.language_id, l.name
HAVING COUNT(*) >= 10
ORDER BY total_views DESC;
