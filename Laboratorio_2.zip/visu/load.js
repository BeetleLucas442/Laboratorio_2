// Run with: node load.js Streamers.csv

const fs = require('fs');
const csv = require('csv-parser');
const mysql = require('mysql2/promise');

const FILE_PATH = process.argv[2] || 'Streamers.csv';
const SEPARATOR = process.argv[3] || ',';

const DB = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'streamers_db', 
};

const REQUIRED_COLUMNS = [
  'NAME',
  'LANGUAGE',
  'MOST_STREAMED_GAME',
  '2ND_MOST_STREAMED_GAME',
  'TOTAL_FOLLOWERS',
  'TOTAL_VIEWS',
  'AVG_VIEWERS_PER_STREAM',
  'ACTIVE_DAYS_PER_WEEK',
];

function readCsv(path, separator) {
  return new Promise((resolve, reject) => {
    const rows = [];
    fs.createReadStream(path)
      .pipe(
        csv({
          separator: separator,
          mapHeaders: ({ header }) => header.replace(/^\uFEFF/, '').trim().toUpperCase(),
        })
      )
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

function parseNumber(value, field) {
  const text = String(value ?? '').trim().replace(',', '.');
  const n = Number(text);
  if (text === '' || Number.isNaN(n)) {
    throw new Error(`Invalid numeric value in ${field}: "${value}"`);
  }
  return n;
}

function parseText(value, field, required = true) {
  const t = String(value ?? '').trim();
  if (required && t === '') throw new Error(`${field} is empty`);
  return t;
}

async function getId(conn, table, idColumn, name) {
  const [r] = await conn.execute(
    `INSERT INTO ${table} (name) VALUES (?)
     ON DUPLICATE KEY UPDATE ${idColumn} = LAST_INSERT_ID(${idColumn})`,
    [name]
  );
  return r.insertId;
}

async function loadRow(conn, row) {
  const name = parseText(row.NAME, 'NAME');
  const language = parseText(row.LANGUAGE, 'LANGUAGE');
  const followers = Math.round(parseNumber(row.TOTAL_FOLLOWERS, 'TOTAL_FOLLOWERS'));
  const views = Math.round(parseNumber(row.TOTAL_VIEWS, 'TOTAL_VIEWS'));
  const avgViewers = Math.round(parseNumber(row.AVG_VIEWERS_PER_STREAM, 'AVG_VIEWERS_PER_STREAM'));
  const days = parseNumber(row.ACTIVE_DAYS_PER_WEEK, 'ACTIVE_DAYS_PER_WEEK');

  const games = [
    parseText(row.MOST_STREAMED_GAME, 'MOST_STREAMED_GAME', false),
    parseText(row['2ND_MOST_STREAMED_GAME'], '2ND_MOST_STREAMED_GAME', false),
  ];

  const languageId = await getId(conn, 'language', 'language_id', language);

  const [r] = await conn.execute(
    `INSERT INTO streamer
       (name, total_followers, total_views, avg_viewers_per_stream, active_days_per_week, language_id)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [name, followers, views, avgViewers, days, languageId]
  );
  const streamerId = r.insertId;

  for (let i = 0; i < games.length; i++) {
    const game = games[i];
    if (game === '') continue; 
    if (i === 1 && game.toLowerCase() === games[0].toLowerCase()) continue; 
    const gameId = await getId(conn, 'game', 'game_id', game);
    await conn.execute(
      'INSERT INTO streamer_game (streamer_id, game_id, position) VALUES (?, ?, ?)',
      [streamerId, gameId, i + 1]
    );
  }
}

async function main() {
  const rows = await readCsv(FILE_PATH, SEPARATOR);
  console.log(`Rows read from the CSV: ${rows.length}`);

  if (rows.length === 0) throw new Error('The CSV has no rows (check the path or the separator)');

  const missing = REQUIRED_COLUMNS.filter((c) => !(c in rows[0]));
  if (missing.length > 0) {
    console.error('Columns found:', Object.keys(rows[0]));
    throw new Error(`Missing columns in the CSV: ${missing.join(', ')} (wrong separator?)`);
  }

  const conn = await mysql.createConnection(DB);
  const errors = [];
  let inserted = 0;

  for (const [i, row] of rows.entries()) {
    const line = i + 2; 
    try {
      await conn.beginTransaction(); 
      await loadRow(conn, row);
      await conn.commit();
      inserted++;
    } catch (e) {
      await conn.rollback();
      errors.push({
        line,
        streamer: row.NAME,
        type: e.code || 'VALIDATION',
        detail: e.sqlMessage || e.message,
      });
    }
  }

  console.log(`\nRows inserted: ${inserted}`);
  console.log(`Rows with errors:  ${errors.length}`);
  if (errors.length > 0) {
    console.table(errors);
    fs.writeFileSync('load_errors.json', JSON.stringify(errors, null, 2));
    console.log('Details saved to load_errors.json');
  }

  const [counts] = await conn.query(
    `SELECT 'language' AS table_name, COUNT(*) AS records FROM language
     UNION ALL SELECT 'game', COUNT(*) FROM game
     UNION ALL SELECT 'streamer', COUNT(*) FROM streamer
     UNION ALL SELECT 'streamer_game', COUNT(*) FROM streamer_game`
  );
  console.log('\nCount per table:');
  console.table(counts);

  await conn.end();
  if (errors.length > 0) process.exitCode = 1;
}

main().catch((e) => {
  console.error('Fatal failure:', e.message);
  process.exit(1);
});
