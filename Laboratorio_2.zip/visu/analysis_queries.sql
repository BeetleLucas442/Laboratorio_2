USE streamers_db;

-- 1a. Ordered by main game
SELECT g.name AS game,
       SUM(sg.position = 1) AS as_main,
       SUM(sg.position = 2) AS as_secondary
FROM streamer_game sg
JOIN game g ON g.game_id = sg.game_id
GROUP BY g.game_id, g.name
ORDER BY as_main DESC, g.name
LIMIT 10;

-- 1b. Ordered by secondary game
SELECT g.name AS game,
       SUM(sg.position = 1) AS as_main,
       SUM(sg.position = 2) AS as_secondary
FROM streamer_game sg
JOIN game g ON g.game_id = sg.game_id
GROUP BY g.game_id, g.name
ORDER BY as_secondary DESC, g.name
LIMIT 10;

SELECT l.name AS language,
       COUNT(*) AS streamers,
       ROUND(AVG(s.total_followers)) AS avg_followers,
       MAX(s.total_followers) AS top_streamer_followers,
       ROUND(MAX(s.total_followers) / SUM(s.total_followers) * 100, 1) AS top_streamer_pct
FROM streamer s
JOIN language l ON l.language_id = s.language_id
GROUP BY l.language_id, l.name
ORDER BY avg_followers DESC;

-- 3a. How many streamers meet the condition
SELECT COUNT(DISTINCT p.streamer_id) AS streamers_whose_main_is_anothers_secondary
FROM streamer_game p
JOIN streamer_game s
  ON s.game_id = p.game_id
 AND s.position = 2
 AND s.streamer_id <> p.streamer_id
WHERE p.position = 1;

-- 3b. Average followers and views by the role of the game
SELECT g.name AS game,
       SUM(sg.position = 1) AS n_main,
       ROUND(AVG(CASE WHEN sg.position = 1 THEN s.total_followers END)) AS avg_followers_main,
       ROUND(AVG(CASE WHEN sg.position = 1 THEN s.total_views END)) AS avg_views_main,
       SUM(sg.position = 2) AS n_secondary,
       ROUND(AVG(CASE WHEN sg.position = 2 THEN s.total_followers END)) AS avg_followers_secondary,
       ROUND(AVG(CASE WHEN sg.position = 2 THEN s.total_views END)) AS avg_views_secondary
FROM streamer_game sg
JOIN streamer s ON s.streamer_id = sg.streamer_id
JOIN game g ON g.game_id = sg.game_id
GROUP BY g.game_id, g.name
HAVING n_main > 0 AND n_secondary > 0
ORDER BY n_main + n_secondary DESC
LIMIT 15;

-- 4a. With filter (records with 0 viewers or 0 active days are discarded)
SELECT CASE
         WHEN active_days_per_week < 2 THEN '1) less than 2 days'
         WHEN active_days_per_week < 4 THEN '2) 2 to 3.9 days'
         WHEN active_days_per_week < 6 THEN '3) 4 to 5.9 days'
         ELSE '4) 6 to 7 days'
       END AS days_range,
       COUNT(*) AS streamers,
       ROUND(AVG(avg_viewers_per_stream)) AS mean_viewers_per_stream
FROM streamer
WHERE avg_viewers_per_stream > 0
  AND active_days_per_week > 0
GROUP BY days_range
ORDER BY days_range;

-- 4b. Without filter
SELECT CASE
         WHEN active_days_per_week < 2 THEN '1) less than 2 days'
         WHEN active_days_per_week < 4 THEN '2) 2 to 3.9 days'
         WHEN active_days_per_week < 6 THEN '3) 4 to 5.9 days'
         ELSE '4) 6 to 7 days'
       END AS days_range,
       COUNT(*) AS streamers,
       ROUND(AVG(avg_viewers_per_stream)) AS mean_viewers_per_stream,
       MAX(avg_viewers_per_stream) AS maximum
FROM streamer
GROUP BY days_range
ORDER BY days_range;
